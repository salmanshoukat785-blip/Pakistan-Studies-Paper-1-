package com.pmsnotes.pakstudies.data

import kotlinx.serialization.Serializable

// Urdu fields (titleUr, shortUr, longUr, pointsUr) are optional. When they are empty
// the app falls back to the English text, so Urdu content can be added later in topics.json.

@Serializable
data class AppData(val sections: List<Section> = emptyList())

@Serializable
data class Section(
    val id: String,
    val title: String,
    val titleUr: String = "",
    val topics: List<Topic> = emptyList()
)

@Serializable
data class Topic(
    val id: Int,
    val title: String,
    val titleUr: String = "",
    val short: String = "",
    val shortUr: String = "",
    val long: String = "",
    val longUr: String = "",
    val headings: List<Heading> = emptyList()
)

@Serializable
data class Heading(
    val title: String,
    val titleUr: String = "",
    val short: String = "",
    val shortUr: String = "",
    val long: String = "",
    val longUr: String = "",
    val points: List<String> = emptyList(),
    val pointsUr: List<String> = emptyList()
)

fun Section.titleIn(ur: Boolean) = if (ur && titleUr.isNotBlank()) titleUr else title
fun Topic.titleIn(ur: Boolean) = if (ur && titleUr.isNotBlank()) titleUr else title
fun Topic.shortIn(ur: Boolean) = if (ur && shortUr.isNotBlank()) shortUr else short
fun Topic.longIn(ur: Boolean) = if (ur && longUr.isNotBlank()) longUr else long
fun Topic.hasUrdu() = titleUr.isNotBlank()
fun Heading.titleIn(ur: Boolean) = if (ur && titleUr.isNotBlank()) titleUr else title
fun Heading.shortIn(ur: Boolean) = if (ur && shortUr.isNotBlank()) shortUr else short
fun Heading.longIn(ur: Boolean) = if (ur && longUr.isNotBlank()) longUr else long
fun Heading.pointsIn(ur: Boolean) = if (ur && pointsUr.isNotEmpty()) pointsUr else points
