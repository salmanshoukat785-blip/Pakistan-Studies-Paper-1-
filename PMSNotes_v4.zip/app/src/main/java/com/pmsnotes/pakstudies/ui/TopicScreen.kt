package com.pmsnotes.pakstudies.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pmsnotes.pakstudies.data.Heading
import com.pmsnotes.pakstudies.data.StudyMode
import com.pmsnotes.pakstudies.data.Topic
import com.pmsnotes.pakstudies.data.hasUrdu
import com.pmsnotes.pakstudies.data.longIn
import com.pmsnotes.pakstudies.data.pointsIn
import com.pmsnotes.pakstudies.data.shortIn
import com.pmsnotes.pakstudies.data.titleIn

private fun showShort(mode: StudyMode) = mode == StudyMode.BOTH || mode == StudyMode.SHORT
private fun showLong(mode: StudyMode) = mode == StudyMode.BOTH || mode == StudyMode.LONG
private fun showPoints(mode: StudyMode) = mode == StudyMode.BOTH || mode == StudyMode.POINTS

@Composable
fun TopicScreen(
    topic: Topic,
    mode: StudyMode,
    bookmarked: Boolean,
    onToggleBookmark: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ur = LocalUr.current
    val expanded = remember(topic.id) { mutableStateMapOf<Int, Boolean>() }
    val allOpen = topic.headings.indices.all { expanded[it] == true }

    Column(modifier.fillMaxSize().background(PageBg)) {
        AppTopBar(if (ur) "موضوع ${topic.id}" else "Topic ${topic.id}", onBack) {
            IconButton(onClick = onToggleBookmark) {
                Text(if (bookmarked) "★" else "☆", color = GoldText, fontSize = 26.sp)
            }
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    topic.titleIn(ur),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            if (ur && !topic.hasUrdu()) {
                item {
                    Text(
                        "اس موضوع کا اردو مواد ابھی دستیاب نہیں، انگریزی مواد دکھایا جا رہا ہے۔",
                        fontSize = 13.sp,
                        color = Color(0xFF8A5A00)
                    )
                }
            }
            if (mode != StudyMode.POINTS) {
                val overview = topic.shortIn(ur)
                if (overview.isNotBlank()) item { InfoCard(if (ur) "جائزہ" else "Overview", overview) }
                val longText = topic.longIn(ur)
                if (longText.isNotBlank() && showLong(mode)) {
                    item { InfoCard(if (ur) "تفصیلی وضاحت" else "Long Detail", longText) }
                }
            }
            item {
                Row(
                    Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (ur) "عنوانات (${topic.headings.size})" else "Headings (${topic.headings.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = {
                        topic.headings.indices.forEach { expanded[it] = !allOpen }
                    }) { Text(if (allOpen) (if (ur) "سب بند کریں" else "Collapse all") else (if (ur) "سب کھولیں" else "Expand all")) }
                }
            }
            itemsIndexed(topic.headings) { index, heading ->
                HeadingCard(
                    index = index,
                    heading = heading,
                    mode = mode,
                    open = expanded[index] == true,
                    onToggle = { expanded[index] = expanded[index] != true }
                )
            }
        }
    }
}

@Composable
private fun HeadingCard(
    index: Int,
    heading: Heading,
    mode: StudyMode,
    open: Boolean,
    onToggle: () -> Unit
) {
    val ur = LocalUr.current
    Card(
        onClick = onToggle,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (open) Color.White else MaterialTheme.colorScheme.primaryContainer
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (open) 3.dp else 1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${index + 1}.",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    heading.titleIn(ur),
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f).padding(horizontal = 10.dp)
                )
                Text(
                    if (open) "▲" else "▼",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            AnimatedVisibility(visible = open) {
                SelectionContainer {
                    Column(Modifier.padding(top = 10.dp)) {
                        if (showShort(mode)) Block(if (ur) "مختصر" else "Short", Color(0xFF2E7D32), heading.shortIn(ur))
                        if (showLong(mode)) Block(if (ur) "تفصیلی" else "Long", Color(0xFFF57C00), heading.longIn(ur))
                        val points = heading.pointsIn(ur)
                        if (showPoints(mode) && points.isNotEmpty()) {
                            Block(
                                if (ur) "مطالعاتی نکات" else "Study Points",
                                Color(0xFF1976D2),
                                points.mapIndexed { i, p -> "${i + 1}. $p" }.joinToString("\n")
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Block(label: String, color: Color, body: String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
        Surface(shape = RoundedCornerShape(50), color = color) {
            Text(
                label,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
            )
        }
        Text(
            body,
            fontSize = 16.sp,
            lineHeight = 24.sp,
            modifier = Modifier.padding(top = 6.dp)
        )
    }
}

@Composable
fun InfoCard(label: String, body: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            SelectionContainer {
                Text(
                    body,
                    fontSize = 16.sp,
                    lineHeight = 24.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }
}
