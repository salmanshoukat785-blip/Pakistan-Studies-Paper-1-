package com.pmsnotes.pakstudies.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pmsnotes.pakstudies.data.AppViewModel
import com.pmsnotes.pakstudies.data.StudyMode
import com.pmsnotes.pakstudies.data.titleIn
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun HomeScreen(
    vm: AppViewModel,
    onOpenTopic: (Int) -> Unit,
    onOpenNotes: (StudyMode) -> Unit,
    onOpenQuiz: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sections = vm.data?.sections ?: return
    val topics = vm.allTopics
    val ur = LocalUr.current
    val headingCount = topics.sumOf { it.headings.size }
    val last = vm.topic(vm.lastTopicId) ?: topics.firstOrNull()
    var showSoon by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(PageBg),
        contentPadding = PaddingValues(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { HeaderBanner() }

        item {
            DashboardCard(
                topicCount = topics.size,
                sectionCount = sections.size,
                headingCount = headingCount,
                modifier = Modifier.padding(horizontal = 12.dp)
            )
        }

        item {
            Column(
                Modifier.padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    Modifier.height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Tile("📚", tr("Short Notes", "مختصر نوٹس"), tr("Quick Revision", "فوری دہرائی"),
                        Color(0xFFD6E9FB), Color(0xFF1976D2), Modifier.weight(1f)) { onOpenNotes(StudyMode.SHORT) }
                    Tile("📝", tr("Long Questions", "طویل سوالات"), tr("Detailed Answers", "تفصیلی جوابات"),
                        Color(0xFFFFE3CF), Color(0xFFF57C00), Modifier.weight(1f)) { onOpenNotes(StudyMode.LONG) }
                }
                Row(
                    Modifier.height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Tile("✅", tr("Important Points", "اہم نکات"), tr("Exam Preparation", "امتحانی تیاری"),
                        Color(0xFFDDF0D5), Color(0xFF2E7D32), Modifier.weight(1f)) { onOpenNotes(StudyMode.POINTS) }
                    Tile("📅", tr("Timeline", "ٹائم لائن"), tr("Dates & Events", "تاریخیں اور واقعات"),
                        Color(0xFFE6DDF7), Color(0xFF6A1B9A), Modifier.weight(1f)) { showSoon = true }
                }
                Row(
                    Modifier.height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Tile("📊", tr("Headings & Subheadings", "عنوانات اور ذیلی عنوانات"), tr("All $headingCount headings", "تمام $headingCount عنوانات"),
                        Color(0xFFFFD9D9), Color(0xFFD32F2F), Modifier.weight(1f)) { onOpenNotes(StudyMode.BOTH) }
                    Tile("❓", tr("MCQs & Self Test", "MCQs اور خود آزمائی"), tr("Check Your Knowledge", "اپنا علم جانچیں"),
                        Color(0xFFD3F3EE), Color(0xFF00897B), Modifier.weight(1f)) { onOpenQuiz() }
                }
            }
        }

        if (last != null) {
            item {
                Column(Modifier.padding(horizontal = 12.dp)) {
                    GreenBar(tr("📖  Continue Reading", "📖  پڑھائی جاری رکھیں"), tr("View All", "سب دیکھیں")) { onOpenNotes(StudyMode.BOTH) }
                    Card(
                        onClick = { onOpenTopic(last.id) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(76.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Brush.verticalGradient(listOf(GreenMid, GreenPrimary))),
                                contentAlignment = Alignment.Center
                            ) { Text("🏛️", fontSize = 34.sp) }
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(urdu(last.title, last.titleUr), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = GreenPrimary)
                                Text(tr("Topic ${last.id}  •  Pakistan Studies-I", "موضوع ${last.id}  •  مطالعۂ پاکستان-I"), fontSize = 13.sp, color = Color(0xFF444444))
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = Color(0xFF1B7F3B),
                                    modifier = Modifier.padding(top = 6.dp)
                                ) {
                                    Text(
                                        tr("✓ Selected Topic", "✓ منتخب موضوع"),
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                    )
                                }
                            }
                            Surface(shape = CircleShape, color = GoldYellow, modifier = Modifier.size(44.dp)) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(chev(), fontSize = 26.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Column(Modifier.padding(horizontal = 12.dp)) {
                GreenBar(tr("☰  Topic-wise Study", "☰  موضوع وار مطالعہ"), tr("View All", "سب دیکھیں")) { onOpenNotes(StudyMode.BOTH) }
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
                    shadowElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        topics.take(5).forEachIndexed { index, topic ->
                            if (index > 0) {
                                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE6E6E6)))
                            }
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { onOpenTopic(topic.id) }
                                    .padding(horizontal = 14.dp, vertical = 11.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                NumberBadge(topic.id, 32.dp)
                                Text(
                                    urdu(topic.title, topic.titleUr),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.weight(1f).padding(horizontal = 12.dp)
                                )
                                Text(chev(), fontSize = 22.sp, color = Color(0xFF333333))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSoon) {
        AlertDialog(
            onDismissRequest = { showSoon = false },
            confirmButton = { TextButton(onClick = { showSoon = false }) { Text(tr("OK", "ٹھیک ہے")) } },
            title = { Text(tr("Coming soon", "جلد آ رہا ہے")) },
            text = { Text(tr("This feature is not available in the notes yet.", "یہ فیچر ابھی نوٹس میں شامل نہیں ہے۔")) }
        )
    }
}

@Composable
private fun HeaderBanner() {
    Box(
        Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(GreenMid, GreenPrimary)))
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        PakistanFlag(Modifier.align(Alignment.TopStart).width(60.dp).height(40.dp))

        Surface(
            shape = RoundedCornerShape(50),
            color = Color(0xFF0E6B2F),
            border = BorderStroke(1.5.dp, Color(0xFF7ED957)),
            modifier = Modifier.align(Alignment.TopEnd)
        ) {
            Text(
                tr("👑 2026 Preparation", "👑 تیاری 2026"),
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }

        Column(
            Modifier.fillMaxWidth().padding(top = 36.dp, bottom = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("PMS", color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.ExtraBold)
            Text(tr("Pakistan Studies-I", "مطالعۂ پاکستان-I"), color = GoldText, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                tr("Study  •  Prepare  •  Excel", "پڑھیں  •  تیاری کریں  •  کامیاب ہوں"),
                color = Color.White,
                fontSize = 17.sp,
                fontStyle = FontStyle.Italic,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun PakistanFlag(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val green = Color(0xFF01411C)
        drawRect(green)
        drawRect(Color.White, size = Size(w * 0.25f, h))
        val c = Offset(w * 0.62f, h * 0.5f)
        val r = h * 0.3f
        drawCircle(Color.White, r, c)
        drawCircle(green, r * 0.85f, Offset(c.x + r * 0.3f, c.y))
        val sc = Offset(c.x + r * 0.55f, c.y - r * 0.3f)
        val sr = r * 0.4f
        val path = Path()
        for (i in 0 until 10) {
            val ang = -Math.PI / 2 + i * Math.PI / 5
            val rad = if (i % 2 == 0) sr else sr * 0.4f
            val x = sc.x + rad * cos(ang).toFloat()
            val y = sc.y + rad * sin(ang).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path, Color.White)
    }
}

@Composable
private fun DashboardCard(
    topicCount: Int,
    sectionCount: Int,
    headingCount: Int,
    modifier: Modifier = Modifier
) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF0B5D2A), Color(0xFF01411C))))
            .padding(2.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF0B5D2A), Color(0xFF01411C))))
            .padding(14.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Surface(shape = RoundedCornerShape(10.dp), color = GoldYellow) {
                Text(
                    tr("YOUR STUDY DASHBOARD", "آپ کا مطالعاتی ڈیش بورڈ"),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    color = Color(0xFF1B1B1B),
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                )
            }
            Row(
                Modifier.padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("📖", fontSize = 46.sp)
                Column(Modifier.padding(start = 14.dp)) {
                    Text(tr("$topicCount Topics", "$topicCount موضوعات"), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        tr("$sectionCount Sections  •  $headingCount Headings", "$sectionCount حصے  •  $headingCount عنوانات"),
                        color = Color.White,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Start
                    )
                }
            }
        }
    }
}

@Composable
private fun Tile(
    emoji: String,
    title: String,
    subtitle: String,
    bg: Color,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier.fillMaxHeight().heightIn(min = 104.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(emoji, fontSize = 28.sp)
                Surface(shape = CircleShape, color = accent.copy(alpha = 0.25f), modifier = Modifier.size(26.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(chev(), fontWeight = FontWeight.Bold, color = accent, fontSize = 18.sp)
                    }
                }
            }
            Text(
                title,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color(0xFF1B1B1B),
                modifier = Modifier.padding(top = 6.dp)
            )
            Text(subtitle, fontSize = 12.sp, color = Color(0xFF444444))
        }
    }
}
