package com.pmsnotes.pakstudies.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pmsnotes.pakstudies.data.AppViewModel
import com.pmsnotes.pakstudies.data.StudyMode

private data class NavItem(val route: String, val label: String, val emoji: String)

private val NAV_ITEMS = listOf(
    NavItem("home", "Home", "🏠"),
    NavItem("notes", "My Notes", "📖"),
    NavItem("bookmarks", "Bookmarks", "⭐"),
    NavItem("progress", "Progress", "📊"),
    NavItem("settings", "Settings", "⚙️")
)

@Composable
fun AppNav(vm: AppViewModel) {
    val nav = rememberNavController()
    val error = vm.error

    if (error != null) {
        ErrorScreen(error)
        return
    }
    if (vm.data == null) {
        LoadingScreen()
        return
    }

    val backEntry by nav.currentBackStackEntryAsState()
    val currentRoute = backEntry?.destination?.route
    val showBottomBar = NAV_ITEMS.any { it.route == currentRoute }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(containerColor = Color.White) {
                    NAV_ITEMS.forEach { item ->
                        NavigationBarItem(
                            selected = currentRoute == item.route,
                            onClick = {
                                if (item.route == "notes") vm.mode = StudyMode.BOTH
                                nav.navigate(item.route) {
                                    popUpTo("home") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Text(item.emoji, fontSize = 20.sp) },
                            label = { Text(item.label, fontSize = 10.sp, maxLines = 1, softWrap = false) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedTextColor = GreenPrimary,
                                indicatorColor = GreenLight
                            )
                        )
                    }
                }
            }
        }
    ) { pad ->
        val screenModifier = Modifier.padding(pad)

        NavHost(navController = nav, startDestination = "home") {

            composable("home") {
                HomeScreen(
                    vm = vm,
                    onOpenTopic = { id ->
                        vm.mode = StudyMode.BOTH
                        nav.navigate("topic/$id")
                    },
                    onOpenNotes = { mode ->
                        vm.mode = mode
                        nav.navigate("notes")
                    },
                    modifier = screenModifier
                )
            }

            composable("notes") {
                NotesScreen(
                    vm = vm,
                    onBack = if (vm.mode == StudyMode.BOTH) null else fun() { nav.popBackStack() },
                    onTopic = { id -> nav.navigate("topic/$id") },
                    modifier = screenModifier
                )
            }

            composable("bookmarks") {
                BookmarksScreen(
                    vm = vm,
                    onTopic = { id ->
                        vm.mode = StudyMode.BOTH
                        nav.navigate("topic/$id")
                    },
                    modifier = screenModifier
                )
            }

            composable("progress") { ProgressScreen(vm, screenModifier) }

            composable("settings") { SettingsScreen(vm, screenModifier) }

            composable(
                route = "topic/{topicId}",
                arguments = listOf(navArgument("topicId") { type = NavType.IntType })
            ) { entry ->
                val topicId = entry.arguments?.getInt("topicId") ?: 0
                val topic = vm.topic(topicId)
                LaunchedEffect(topicId) { vm.openTopic(topicId) }
                if (topic != null) {
                    TopicScreen(
                        topic = topic,
                        mode = vm.mode,
                        bookmarked = topicId in vm.bookmarks,
                        onToggleBookmark = { vm.toggleBookmark(topicId) },
                        onBack = { nav.popBackStack() },
                        modifier = screenModifier
                    )
                }
            }
        }
    }
}
