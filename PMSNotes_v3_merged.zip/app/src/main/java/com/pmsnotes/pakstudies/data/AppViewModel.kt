package com.pmsnotes.pakstudies.data

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

enum class StudyMode(val label: String, val hint: String) {
    BOTH("My Notes", "Heading par click karein: Short aur Long dono neeche khulenge"),
    SHORT("Short Notes", "Heading par click karein: sirf Short detail khulegi"),
    LONG("Long Questions", "Heading par click karein: sirf Long detail khulegi"),
    POINTS("Important Points", "Heading par click karein: Study Points khulenge")
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("pms_prefs", Context.MODE_PRIVATE)

    var data by mutableStateOf<AppData?>(null)
        private set

    var error by mutableStateOf<String?>(null)
        private set

    var mode by mutableStateOf(StudyMode.BOTH)

    var lastTopicId by mutableStateOf(prefs.getInt("last", 1))
        private set

    var visited by mutableStateOf(readSet("visited"))
        private set

    var bookmarks by mutableStateOf(readSet("bookmarks"))
        private set

    var fontScale by mutableStateOf(prefs.getFloat("font", 1f))
        private set

    init {
        viewModelScope.launch {
            try {
                val loaded = withContext(Dispatchers.IO) {
                    val text = getApplication<Application>().assets
                        .open("topics.json")
                        .bufferedReader(Charsets.UTF_8)
                        .use { it.readText() }
                    Json { ignoreUnknownKeys = true }.decodeFromString<AppData>(text)
                }
                data = loaded
            } catch (e: Exception) {
                error = e.message ?: "Data load nahi ho saka"
            }
        }
    }

    val allTopics: List<Topic>
        get() = data?.sections?.flatMap { it.topics } ?: emptyList()

    fun topic(id: Int): Topic? = allTopics.firstOrNull { it.id == id }

    fun openTopic(id: Int) {
        lastTopicId = id
        prefs.edit().putInt("last", id).apply()
        if (id !in visited) {
            visited = visited + id
            writeSet("visited", visited)
        }
    }

    fun toggleBookmark(id: Int) {
        bookmarks = if (id in bookmarks) bookmarks - id else bookmarks + id
        writeSet("bookmarks", bookmarks)
    }

    fun updateFontScale(scale: Float) {
        fontScale = scale
        prefs.edit().putFloat("font", scale).apply()
    }

    fun resetProgress() {
        visited = emptySet()
        bookmarks = emptySet()
        lastTopicId = 1
        prefs.edit().remove("visited").remove("bookmarks").putInt("last", 1).apply()
    }

    private fun readSet(key: String): Set<Int> =
        (prefs.getStringSet(key, emptySet()) ?: emptySet())
            .mapNotNull { it.toIntOrNull() }
            .toSet()

    private fun writeSet(key: String, set: Set<Int>) {
        prefs.edit().putStringSet(key, set.map { it.toString() }.toSet()).apply()
    }
}
