package com.pmsnotes.pakstudies.data

import kotlinx.serialization.Serializable

@Serializable
data class AppData(val sections: List<Section> = emptyList())

@Serializable
data class Section(
    val id: String,
    val title: String,
    val topics: List<Topic> = emptyList()
)

@Serializable
data class Topic(
    val id: Int,
    val title: String,
    val short: String = "",
    val long: String = "",
    val headings: List<Heading> = emptyList()
)

@Serializable
data class Heading(
    val title: String,
    val short: String = "",
    val long: String = "",
    val points: List<String> = emptyList()
)
