package com.pmsnotes.pakstudies.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.pmsnotes.pakstudies.data.UrTranslator
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

/** True when the app language is Urdu. Provided in MainActivity. */
val LocalUr = compositionLocalOf { false }

/** True when Urdu is on with "online translation" (language option "urtr"). */
val LocalAutoTr = compositionLocalOf { false }

/** Picks the English or Urdu (Urdu script) text for the current language. */
@Composable
fun tr(en: String, ur: String): String = if (LocalUr.current) ur else en

/** Forward chevron that flips in right-to-left layout. */
@Composable
fun chev(): String = if (LocalLayoutDirection.current == LayoutDirection.Rtl) "‹" else "›"

/** Back arrow that flips in right-to-left layout. */
@Composable
fun backGlyph(): String = if (LocalLayoutDirection.current == LayoutDirection.Rtl) "→" else "←"

/**
 * Text for the current language. In Urdu mode it uses the stored Urdu text when there is
 * one; otherwise the English text is translated on the phone (and cached). The English text
 * is shown until the translation is ready.
 */
@Composable
fun urdu(en: String, ur: String = ""): String {
    val isUr = LocalUr.current
    val ctx = LocalContext.current.applicationContext
    val needs = isUr && LocalAutoTr.current && ur.isBlank() && en.isNotBlank()
    var text by remember(en, needs) { mutableStateOf(if (needs) (UrTranslator.cached(ctx, en) ?: en) else en) }
    LaunchedEffect(en, needs, UrTranslator.state) {
        if (needs) UrTranslator.translate(ctx, en)?.let { text = it }
    }
    return if (!isUr) en else if (ur.isNotBlank()) ur else text
}

/** Same as [urdu] for a list of texts (for example MCQ options). */
@Composable
fun urduList(en: List<String>, ur: List<String> = emptyList()): List<String> {
    val useStored = ur.size == en.size && ur.all { it.isNotBlank() }
    return en.mapIndexed { i, s -> urdu(s, if (useStored) ur[i] else "") }
}
