import docx, re, json, sys
SRC, OUT = sys.argv[1:3]
d = docx.Document(SRC)
P = [(p.style.name, p.text.strip()) for p in d.paragraphs if p.text.strip()]
sections, sec, topic, head = [], None, None, None
for s, t in P:
    if s == 'Heading 1':
        m = re.match(r'([A-E])\. (.+)', t)
        if m:
            sec = {'id': m.group(1), 'title': m.group(2).strip(), 'topics': []}
            sections.append(sec); topic = head = None; continue
        m = re.match(r'(\d+)\. (.+)', t)
        if m and sec is not None:
            topic = {'id': int(m.group(1)), 'title': m.group(2).strip(), 'short': '', 'long': '', 'headings': []}
            sec['topics'].append(topic); head = None; continue
        continue
    if topic is None:
        continue
    if s == 'Heading 2':
        m = re.match(r'(\d+)\. (.+)', t)
        head = {'title': (m.group(2) if m else t).strip(), 'short': '', 'long': '', 'points': []}
        topic['headings'].append(head)
    elif s == 'Normal':
        if head is None:
            topic['short'] = (topic['short'] + ' ' + t).strip()
        elif t.startswith('Short Detail:'):
            head['short'] = t.split(':', 1)[1].strip()
        elif t.startswith('Long Detail:'):
            head['long'] = t.split(':', 1)[1].strip()
        elif t.startswith('Key study points:'):
            head['points'] = [x.strip() for x in t.split(':', 1)[1].split('|') if x.strip()]
for sc in sections:
    for tp in sc['topics']:
        for h in tp['headings']:
            if not h['points']:
                h['points'] = [h['short']]
json.dump({'sections': sections}, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
T = [t for s in sections for t in s['topics']]
H = [h for t in T for h in t['headings']]
print('sections', [(s['id'], len(s['topics'])) for s in sections])
print('topics', len(T), 'ids == 1..N in order:', [t['id'] for t in T] == list(range(1, len(T) + 1)))
print('headings', len(H), 'per topic', {len(t['headings']) for t in T})
print('empty short/long/intro:', sum(1 for h in H if not h['short'] or not h['long']), sum(1 for t in T if not t['short']))
print('real key points:', sum(1 for h in H if len(h['points']) > 1 or h['points'][0] != h['short']))
print(sections[4]['title'])
