# Keep serialization models
-keep class com.pmsnotes.pakstudies.data.** { *; }
