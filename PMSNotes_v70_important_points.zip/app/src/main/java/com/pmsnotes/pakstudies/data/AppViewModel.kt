package com.pmsnotes.pakstudies.data

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

enum class StudyMode(
    private val labelEn: String, private val labelUr: String,
    private val hintEn: String, private val hintUr: String
) {
    BOTH(
        "My Notes", "میرے نوٹس",
        "Tap a topic to see its headings",
        "موضوع پر ٹیپ کریں: اس کے عنوانات نظر آئیں گے"
    ),
    SHORT(
        "Short Notes", "مختصر نوٹس",
        "Tap a topic to see its headings",
        "موضوع پر ٹیپ کریں: اس کے عنوانات نظر آئیں گے"
    ),
    LONG(
        "Long Questions", "طویل سوالات",
        "Tap a topic to see its headings",
        "موضوع پر ٹیپ کریں: اس کے عنوانات نظر آئیں گے"
    ),
    POINTS(
        "Important Points", "اہم نکات",
        "Tap a topic to see its headings",
        "موضوع پر ٹیپ کریں: اس کے عنوانات نظر آئیں گے"
    );

    fun label(ur: Boolean) = if (ur) labelUr else labelEn
    fun hint(ur: Boolean) = if (ur) hintUr else hintEn
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("pms_prefs", Context.MODE_PRIVATE)

    var data by mutableStateOf<AppData?>(null)
        private set

    var error by mutableStateOf<String?>(null)
        private set

    var mode by mutableStateOf(StudyMode.BOTH)

    var mcqs by mutableStateOf<List<Mcq>>(emptyList())
        private set

    var timeline by mutableStateOf<List<TimelineEvent>>(emptyList())
        private set

    var lastTopicId by mutableStateOf(prefs.getInt("last", 1))
        private set

    var visited by mutableStateOf(readSet("visited"))
        private set

    var bookmarks by mutableStateOf(readSet("bookmarks"))
        private set

    var fontScale by mutableStateOf(prefs.getFloat("font", 1f))
        private set

    var lang by mutableStateOf(prefs.getString("lang", "en") ?: "en")
        private set

    fun updateLang(code: String) {
        lang = code
        prefs.edit().putString("lang", code).apply()
    }

    init {
        viewModelScope.launch {
            try {
                val loaded = withContext(Dispatchers.IO) {
                    val text = getApplication<Application>().assets
                        .open("topics.json")
                        .bufferedReader(Charsets.UTF_8)
                        .use { it.readText() }
                    Json { ignoreUnknownKeys = true }.decodeFromString<AppData>(text)
                }
                data = loaded
                mcqs = withContext(Dispatchers.IO) {
                    try {
                        val text = getApplication<Application>().assets
                            .open("mcqs.json")
                            .bufferedReader(Charsets.UTF_8)
                            .use { it.readText() }
                        Json { ignoreUnknownKeys = true }.decodeFromString<List<Mcq>>(text)
                    } catch (e: Exception) {
                        emptyList()
                    }
                }
                timeline = withContext(Dispatchers.IO) {
                    try {
                        val text = getApplication<Application>().assets
                            .open("timeline.json")
                            .bufferedReader(Charsets.UTF_8)
                            .use { it.readText() }
                        Json { ignoreUnknownKeys = true }.decodeFromString<List<TimelineEvent>>(text)
                    } catch (e: Exception) {
                        emptyList()
                    }
                }
            } catch (e: Exception) {
                error = e.message ?: "Could not load data"
            }
        }
    }

    val allTopics: List<Topic>
        get() = data?.sections?.flatMap { it.topics } ?: emptyList()

    fun topic(id: Int): Topic? = allTopics.firstOrNull { it.id == id }

    fun mcqsFor(topicId: Int): List<Mcq> = mcqs.filter { it.t == topicId }

    /** Random questions from all topics; the same question text is never repeated. */
    fun randomMix(count: Int): List<Mcq> {
        val seen = HashSet<String>()
        return mcqs.shuffled()
            .filter { q -> seen.add(q.q.lowercase().filter { it.isLetterOrDigit() }) }
            .take(count)
    }

    fun openTopic(id: Int) {
        lastTopicId = id
        prefs.edit().putInt("last", id).apply()
        if (id !in visited) {
            visited = visited + id
            writeSet("visited", visited)
        }
    }

    fun toggleBookmark(id: Int) {
        bookmarks = if (id in bookmarks) bookmarks - id else bookmarks + id
        writeSet("bookmarks", bookmarks)
    }

    fun updateFontScale(scale: Float) {
        fontScale = scale
        prefs.edit().putFloat("font", scale).apply()
    }

    fun resetProgress() {
        visited = emptySet()
        bookmarks = emptySet()
        lastTopicId = 1
        prefs.edit().remove("visited").remove("bookmarks").putInt("last", 1).apply()
    }

    private fun readSet(key: String): Set<Int> =
        (prefs.getStringSet(key, emptySet()) ?: emptySet())
            .mapNotNull { it.toIntOrNull() }
            .toSet()

    private fun writeSet(key: String, set: Set<Int>) {
        prefs.edit().putStringSet(key, set.map { it.toString() }.toSet()).apply()
    }
}
