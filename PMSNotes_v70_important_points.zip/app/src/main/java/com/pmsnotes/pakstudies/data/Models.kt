package com.pmsnotes.pakstudies.data

import kotlinx.serialization.Serializable

// Urdu fields (titleUr, shortUr, longUr, pointsUr) are optional. When they are empty
// the app falls back to the English text, so Urdu content can be added later in topics.json.

@Serializable
data class AppData(val sections: List<Section> = emptyList())

@Serializable
data class Section(
    val id: String,
    val title: String,
    val titleUr: String = "",
    val topics: List<Topic> = emptyList()
)

@Serializable
data class Topic(
    val id: Int,
    val title: String,
    val titleUr: String = "",
    val short: String = "",
    val shortUr: String = "",
    val long: String = "",
    val longUr: String = "",
    val points: List<String> = emptyList(),
    val headings: List<Heading> = emptyList(),
    val vocab: List<Vocab> = emptyList()
)

// A difficult word with its Urdu meaning (Urdu script).
@Serializable
data class Vocab(val w: String, val ur: String)

@Serializable
data class Heading(
    val title: String,
    val titleUr: String = "",
    val short: String = "",
    val shortUr: String = "",
    val long: String = "",
    val longUr: String = "",
    val points: List<String> = emptyList(),
    val pointsUr: List<String> = emptyList()
)

fun Section.titleIn(ur: Boolean) = if (ur && titleUr.isNotBlank()) titleUr else title
fun Topic.titleIn(ur: Boolean) = if (ur && titleUr.isNotBlank()) titleUr else title
fun Topic.shortIn(ur: Boolean) = if (ur && shortUr.isNotBlank()) shortUr else short
fun Topic.longIn(ur: Boolean) = if (ur && longUr.isNotBlank()) longUr else long
fun Topic.hasUrdu() = titleUr.isNotBlank()
fun Heading.titleIn(ur: Boolean) = if (ur && titleUr.isNotBlank()) titleUr else title
fun Heading.shortIn(ur: Boolean) = if (ur && shortUr.isNotBlank()) shortUr else short
fun Heading.longIn(ur: Boolean) = if (ur && longUr.isNotBlank()) longUr else long
fun Heading.pointsIn(ur: Boolean) = if (ur && pointsUr.isNotEmpty()) pointsUr else points

// One timeline event: y = year text, e = event text, t = related topic id (0 = none), era = group title.
@Serializable
data class TimelineEvent(
    val y: String,
    val e: String,
    val eUr: String = "",
    val t: Int = 0,
    val era: String = ""
)

// One multiple-choice question. t = topic id, o = four options, a = index of the correct option.
// qUr / oUr / eUr are optional Urdu versions (English is shown when they are empty).
@Serializable
data class Mcq(
    val t: Int,
    val q: String,
    val qUr: String = "",
    val o: List<String>,
    val oUr: List<String> = emptyList(),
    val a: Int,
    val e: String = "",
    val eUr: String = ""
)

fun Mcq.qIn(ur: Boolean) = if (ur && qUr.isNotBlank()) qUr else q
fun Mcq.oIn(ur: Boolean) = if (ur && oUr.size == o.size) oUr else o
fun Mcq.eIn(ur: Boolean) = if (ur && eUr.isNotBlank()) eUr else e
