package com.pmsnotes.pakstudies.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val GreenPrimary = Color(0xFF01411C)
val GreenMid = Color(0xFF0B5D2A)
val GreenLight = Color(0xFFE8F5E9)
val GoldYellow = Color(0xFFFFC107)
val GoldText = Color(0xFFFFD54F)
val PageBg = Color(0xFFF2F5F2)

private val Colors = lightColorScheme(
    primary = GreenPrimary,
    onPrimary = Color.White,
    primaryContainer = GreenLight,
    onPrimaryContainer = GreenPrimary,
    secondary = Color(0xFF2E7D32),
    background = PageBg,
    surface = Color.White
)

@Composable
fun PmsTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
