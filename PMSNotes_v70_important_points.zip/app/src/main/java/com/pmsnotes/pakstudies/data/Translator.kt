package com.pmsnotes.pakstudies.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/**
 * English -> Urdu translation with Google ML Kit. The Urdu model is downloaded once
 * (internet needed the first time); after that translation also works offline.
 * Every translated text is cached on the phone so it is translated only once.
 */
object UrTranslator {

    /** "idle", "downloading", "ready" or "error". Observed by the UI. */
    var state by mutableStateOf("idle")
        private set

    private val memory = ConcurrentHashMap<String, String>()
    private val lock = Mutex()
    private var client: Translator? = null
    private var modelReady = false

    private fun key(text: String): String =
        MessageDigest.getInstance("MD5").digest(text.toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun cacheFile(ctx: Context, k: String): File {
        val dir = File(ctx.filesDir, "tr_ur")
        if (!dir.exists()) dir.mkdirs()
        return File(dir, k)
    }

    /** Returns a previously translated text, or null. Cheap, safe to call from composition. */
    fun cached(ctx: Context, text: String): String? {
        val k = key(text)
        memory[k]?.let { return it }
        return try {
            val f = cacheFile(ctx, k)
            if (f.exists()) f.readText().also { memory[k] = it } else null
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun <T> Task<T>.await(): T = suspendCoroutine { cont ->
        addOnSuccessListener { cont.resume(it) }
        addOnFailureListener { cont.resumeWithException(it) }
    }

    private fun getClient(): Translator {
        client?.let { return it }
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.URDU)
            .build()
        return Translation.getClient(options).also { client = it }
    }

    /** Downloads the Urdu model if needed. Returns true when the model is ready. */
    suspend fun prepare(): Boolean = lock.withLock {
        if (modelReady) return true
        state = "downloading"
        try {
            getClient().downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            modelReady = true
            state = "ready"
            true
        } catch (e: Exception) {
            state = "error"
            false
        }
    }

    /** Splits long text into pieces at sentence ends so the model handles each one well. */
    private fun chunks(text: String): List<String> {
        val parts = ArrayList<String>()
        val sb = StringBuilder()
        for (sentence in text.split(Regex("(?<=[.!?])\\s+"))) {
            if (sb.isNotEmpty() && sb.length + sentence.length > 400) {
                parts.add(sb.toString()); sb.setLength(0)
            }
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(sentence)
        }
        if (sb.isNotEmpty()) parts.add(sb.toString())
        return parts
    }

    /** Translates [text] to Urdu. Returns null when the model is not available yet. */
    suspend fun translate(ctx: Context, text: String): String? {
        if (text.isBlank()) return text
        cached(ctx, text)?.let { return it }
        return withContext(Dispatchers.Default) {
            if (!modelReady && !prepare()) return@withContext null
            lock.withLock {
                try {
                    val pieces = ArrayList<String>()
                    for (c in chunks(text)) pieces.add(getClient().translate(c).await())
                    val out = pieces.joinToString(" ")
                    memory[key(text)] = out
                    try { cacheFile(ctx, key(text)).writeText(out) } catch (_: Exception) {}
                    out
                } catch (e: Exception) {
                    null
                }
            }
        }
    }
}
