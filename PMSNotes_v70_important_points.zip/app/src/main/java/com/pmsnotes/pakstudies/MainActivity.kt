package com.pmsnotes.pakstudies

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import android.widget.Toast
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import com.pmsnotes.pakstudies.data.UrTranslator
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pmsnotes.pakstudies.data.AppViewModel
import com.pmsnotes.pakstudies.ui.AppNav
import com.pmsnotes.pakstudies.ui.LocalAutoTr
import com.pmsnotes.pakstudies.ui.LocalUr
import com.pmsnotes.pakstudies.ui.PmsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: AppViewModel = viewModel()
            val base = LocalDensity.current
            CompositionLocalProvider(
                LocalDensity provides Density(base.density, base.fontScale * vm.fontScale)
            ) {
                // Urdu always uses online translation; "urtr" is kept only for an older saved setting.
                val ur = vm.lang == "ur" || vm.lang == "urtr"
                val auto = ur
                val ctx = LocalContext.current
                // Download the Urdu translation model when Urdu is switched on.
                LaunchedEffect(auto) {
                    if (auto) UrTranslator.prepare()
                }
                LaunchedEffect(UrTranslator.state, auto) {
                    if (auto && UrTranslator.state == "downloading") {
                        Toast.makeText(ctx, "اردو ترجمے کا ماڈل ڈاؤن لوڈ ہو رہا ہے، انٹرنیٹ آن رکھیں", Toast.LENGTH_LONG).show()
                    } else if (auto && UrTranslator.state == "error") {
                        Toast.makeText(ctx, "ماڈل ڈاؤن لوڈ نہیں ہو سکا۔ انٹرنیٹ چیک کریں، انگریزی دکھائی جا رہی ہے", Toast.LENGTH_LONG).show()
                    }
                }
                CompositionLocalProvider(
                    LocalUr provides ur,
                    LocalAutoTr provides auto,
                    LocalLayoutDirection provides (if (ur) LayoutDirection.Rtl else LayoutDirection.Ltr)
                ) {
                    PmsTheme { AppNav(vm) }
                }
            }
        }
    }
}
