# PMS Pakistan Studies-I (Android App)

Punjab PMS Pakistan Studies-I: 105 topics in 5 sections (A to E), 12 to 16 headings per topic (1560 headings).
Headings are listed as titles for now (their details are not included). Works offline. Kotlin + Jetpack Compose.

MCQs: 10 questions for every topic (1050 in total) in `app/src/main/assets/mcqs.json`, opened from Home > MCQs & Self Test (per topic or a random mix).

Screens: Dashboard (Home), My Notes, Bookmarks, Progress, Settings, MCQs & Self Test.
Open a topic to see its headings.

## Language
Settings > Language switches the whole app between English and Urdu (Urdu script, right-to-left layout).
Menus and labels are fully translated. Notes content is English for now. When Urdu text for a topic is missing,
the app shows the English text with a short notice.

To add Urdu content, fill these optional fields in `app/src/main/assets/topics.json`:
`titleUr` (section, topic, heading), `shortUr` / `longUr` (topic, heading) and `pointsUr` (heading).

## Build the APK on GitHub
1. Create a new GitHub repository (public or private).
2. Upload everything inside this project to the repository, including the hidden `.github` folder.
   If the web upload skips `.github`, use **Add file > Create new file**, type `.github/workflows/build.yml`
   as the name and paste the file content.
3. After the upload, **Actions > Build APK** starts by itself (5 to 10 minutes).
4. Open the finished run, download the artifact `PMS-PakStudies-APK` and extract it to get `PMS-PakStudies.apk`.
5. Copy the APK to the phone and install it (allow "Install unknown apps" in Settings).

### Upload a zip instead
If a `.zip` file with the whole project is uploaded to the top level of the repository, the workflow
unzips it and builds the project inside it. If there is no zip, the repository itself is built.

### Release (optional)
Push a tag such as `v1.0`; the APK is attached to the **Releases** page.

## Updating the notes
`app/src/main/assets/topics.json` holds all notes. To rebuild it from the English Word file run:
`python3 tools/parse_docx.py <notes.docx> app/src/main/assets/topics.json`
