package com.pmsnotes.pakstudies.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

/** True when the app language is Urdu. Provided in MainActivity. */
val LocalUr = compositionLocalOf { false }

/** Picks the English or Urdu (Urdu script) text for the current language. */
@Composable
fun tr(en: String, ur: String): String = if (LocalUr.current) ur else en

/** Forward chevron that flips in right-to-left layout. */
@Composable
fun chev(): String = if (LocalLayoutDirection.current == LayoutDirection.Rtl) "‹" else "›"

/** Back arrow that flips in right-to-left layout. */
@Composable
fun backGlyph(): String = if (LocalLayoutDirection.current == LayoutDirection.Rtl) "→" else "←"
