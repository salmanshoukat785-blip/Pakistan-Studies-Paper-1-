package com.pmsnotes.pakstudies.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pmsnotes.pakstudies.data.AppViewModel
import com.pmsnotes.pakstudies.data.eIn
import com.pmsnotes.pakstudies.data.oIn
import com.pmsnotes.pakstudies.data.qIn
import com.pmsnotes.pakstudies.data.titleIn

/** Topic picker for the MCQ self test. Topic id 0 means a random mix of 20 questions. */
@Composable
fun QuizHomeScreen(
    vm: AppViewModel,
    onStart: (Int) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sections = vm.data?.sections ?: emptyList()
    Column(modifier.fillMaxSize().background(PageBg)) {
        AppTopBar(tr("MCQs & Self Test", "MCQs اور خود آزمائی"), onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Card(
                    onClick = { onStart(0) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = GreenPrimary)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            tr("🎲 Random Mix", "🎲 رینڈم مکس"),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            tr("20 questions from all topics", "تمام موضوعات سے 20 سوالات"),
                            color = Color.White,
                            fontSize = 13.sp
                        )
                    }
                }
            }
            sections.forEach { section ->
                item(key = "quiz_section_${section.id}") { SectionHeader(section) }
                items(section.topics, key = { "quiz_topic_${it.id}" }) { topic ->
                    TopicCard(topic) { onStart(topic.id) }
                }
            }
        }
    }
}

@Composable
fun QuizScreen(
    vm: AppViewModel,
    topicId: Int,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ur = LocalUr.current
    var round by remember { mutableStateOf(0) }
    val questions = remember(topicId, round) {
        if (topicId == 0) vm.randomMix(20) else vm.mcqsFor(topicId).shuffled()
    }
    var index by remember(topicId, round) { mutableStateOf(0) }
    var picked by remember(topicId, round) { mutableStateOf<Int?>(null) }
    var score by remember(topicId, round) { mutableStateOf(0) }
    val title = if (topicId == 0) tr("Random Mix", "رینڈم مکس") else (vm.topic(topicId)?.titleIn(ur) ?: "")

    Column(modifier.fillMaxSize().background(PageBg)) {
        AppTopBar(title, onBack)

        if (questions.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(tr("No questions yet.", "ابھی سوالات موجود نہیں۔"))
            }
        } else if (index >= questions.size) {
            val total = questions.size
            val pct = score * 100 / total
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("🏁", fontSize = 56.sp)
                Text(
                    "$score / $total",
                    fontSize = 40.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = GreenPrimary
                )
                Text("$pct%", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    when {
                        pct >= 80 -> tr("Excellent!", "شاندار!")
                        pct >= 50 -> tr("Good effort, keep practising.", "اچھی کوشش، مشق جاری رکھیں۔")
                        else -> tr("Revise this topic and try again.", "موضوع دوبارہ پڑھیں اور پھر کوشش کریں۔")
                    },
                    modifier = Modifier.padding(top = 8.dp, bottom = 20.dp)
                )
                Button(
                    onClick = { round += 1 },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary)
                ) { Text(tr("Try again", "دوبارہ کوشش کریں")) }
                TextButton(onClick = onBack) { Text(tr("Back to topics", "موضوعات پر واپس")) }
            }
        } else {
            val q = questions[index]
            val options = q.oIn(ur)
            val order = remember(q) { options.indices.toList().shuffled() }
            val correctPos = order.indexOf(q.a)
            val answered = picked
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Column {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                tr("Question ${index + 1} / ${questions.size}", "سوال ${index + 1} / ${questions.size}"),
                                fontWeight = FontWeight.Bold,
                                color = GreenPrimary
                            )
                            Text(tr("Score: $score", "اسکور: $score"), color = GreenPrimary)
                        }
                        Box(
                            Modifier
                                .padding(top = 8.dp)
                                .fillMaxWidth()
                                .height(8.dp)
                                .background(Color(0xFFD7E3D8), RoundedCornerShape(50))
                        ) {
                            Box(
                                Modifier
                                    .fillMaxWidth((index + 1f) / questions.size)
                                    .fillMaxHeight()
                                    .background(GreenPrimary, RoundedCornerShape(50))
                            )
                        }
                    }
                }
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Text(
                            q.qIn(ur),
                            modifier = Modifier.padding(16.dp),
                            fontSize = 18.sp,
                            lineHeight = 26.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
                order.forEachIndexed { pos, original ->
                    item(key = "opt_${index}_$pos") {
                        val bg = when {
                            answered == null -> Color.White
                            pos == correctPos -> Color(0xFFDFF3E0)
                            pos == answered -> Color(0xFFFFE0E0)
                            else -> Color.White
                        }
                        Card(
                            onClick = {
                                if (picked == null) {
                                    picked = pos
                                    if (pos == correctPos) score += 1
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = bg),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (answered != null && pos == correctPos) Color(0xFF2E7D32)
                                    else if (answered != null && pos == answered) Color(0xFFC62828)
                                    else GreenLight,
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            "${'A' + pos}",
                                            fontWeight = FontWeight.Bold,
                                            color = if (answered != null && (pos == correctPos || pos == answered)) Color.White else GreenPrimary
                                        )
                                    }
                                }
                                Text(
                                    options[original],
                                    modifier = Modifier.padding(horizontal = 12.dp).weight(1f),
                                    fontSize = 16.sp
                                )
                            }
                        }
                    }
                }
                if (answered != null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1))
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Text(
                                    if (answered == correctPos) tr("✓ Correct", "✓ درست") else tr("✗ Incorrect", "✗ غلط"),
                                    fontWeight = FontWeight.Bold,
                                    color = if (answered == correctPos) Color(0xFF2E7D32) else Color(0xFFC62828)
                                )
                                if (q.eIn(ur).isNotBlank()) {
                                    Text(q.eIn(ur), modifier = Modifier.padding(top = 6.dp), fontSize = 15.sp, lineHeight = 22.sp)
                                }
                            }
                        }
                    }
                    item {
                        Button(
                            onClick = {
                                index += 1
                                picked = null
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary)
                        ) {
                            Text(
                                if (index + 1 >= questions.size) tr("Finish", "ختم کریں") else tr("Next", "اگلا"),
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
